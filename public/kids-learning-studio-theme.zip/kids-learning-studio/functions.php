<?php
/**
 * Kids Learning Studio Theme Functions
 *
 * @package Kids_Learning_Studio
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function kls_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'kids-learning-studio' ),
        'footer'  => __( 'Footer Menu', 'kids-learning-studio' ),
    ) );
}
add_action( 'after_setup_theme', 'kls_theme_setup' );

function kls_enqueue_assets() {
    $theme_uri = get_template_directory_uri();
    $version   = '1.0.0';

    wp_enqueue_style(
        'kls-google-fonts',
        'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@500;600&family=Outfit:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    if ( 'index-xpLvzgcs.css' !== '' ) {
        wp_enqueue_style( 'kls-app-style', $theme_uri . '/assets/index-xpLvzgcs.css', array(), $version );
    }

    if ( 'index-CyqkM0SV.js' !== '' ) {
        wp_enqueue_script( 'kls-app-script', $theme_uri . '/assets/index-CyqkM0SV.js', array(), $version, true );
    }
}
add_action( 'wp_enqueue_scripts', 'kls_enqueue_assets' );

function kls_add_module_attribute( $tag, $handle, $src ) {
    if ( 'kls-app-script' === $handle ) {
        return '<script type="module" src="' . esc_url( $src ) . '"></script>' . "\n";
    }
    return $tag;
}
add_filter( 'script_loader_tag', 'kls_add_module_attribute', 10, 3 );

/**
 * Register Learning Resource Custom Post Type & Taxonomies for WordPress Admin
 */
function kls_register_post_types() {
    register_post_type( 'learning_resource', array(
        'labels' => array(
            'name'          => __( 'Learning Resources', 'kids-learning-studio' ),
            'singular_name' => __( 'Learning Resource', 'kids-learning-studio' ),
        ),
        'public'       => true,
        'has_archive'  => true,
        'menu_icon'    => 'dashicons-welcome-learn-more',
        'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'show_in_rest' => true,
        'rewrite'      => array( 'slug' => 'resources' ),
    ) );

    register_taxonomy( 'resource_category', 'learning_resource', array(
        'label'        => __( 'Resource Categories', 'kids-learning-studio' ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ) );

    register_taxonomy( 'age_group', 'learning_resource', array(
        'label'        => __( 'Age Groups', 'kids-learning-studio' ),
        'hierarchical' => true,
        'show_in_rest' => true,
    ) );
}
add_action( 'init', 'kls_register_post_types' );

/**
 * Serve theme SPA routes cleanly without 404 headers
 */
function kls_spa_route_fallback( $template ) {
    if ( is_404() ) {
        $path = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
        $prefixes = array( 'free-resources', 'resources', 'shop', 'blog', 'about', 'contact', 'faq', 'support', 'downloads', 'privacy', 'cookies', 'terms', 'refunds', 'studio-admin' );
        foreach ( $prefixes as $prefix ) {
            if ( $path === $prefix || strpos( $path, $prefix . '/' ) === 0 ) {
                status_header( 200 );
                return get_template_directory() . '/index.php';
            }
        }
    }
    return $template;
}
add_filter( 'template_include', 'kls_spa_route_fallback' );
