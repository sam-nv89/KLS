<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
$theme_uri = get_template_directory_uri();
$og_image  = $theme_uri . '/assets/aistudio/fbeea20a-47bd-4212-b240-9c1a75bf70c4_2f1d3942.png';
?><!doctype html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Free and printable educational worksheets, coloring pages, math games, and activity packs for kids ages 2–6. Learn, play, and create at home or preschool." />
    <meta property="og:type" content="website" />
    <meta property="og:site_name" content="<?php bloginfo( 'name' ); ?>" />
    <meta property="og:image" content="<?php echo esc_url( $og_image ); ?>" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:image" content="<?php echo esc_url( $og_image ); ?>" />
    <script>
      window.__KLS_ASSET_BASE__ = <?php echo wp_json_encode( $theme_uri ); ?>;
    </script>
    <?php wp_head(); ?>
  </head>
  <body <?php body_class( 'bg-[#FCFBF8] text-[#0F2A5F] antialiased' ); ?>>
    <?php wp_body_open(); ?>
    <div id="root"></div>
    <?php wp_footer(); ?>
  </body>
</html>
